/**
 * Outer constructor.
 * @constructor
 */
function Outer() {
}

/**
 * Inner constructor.
 * @constructor
 */
Outer.Inner = function() {
};
