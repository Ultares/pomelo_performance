/// <reference path="./test.d.ts" />
import * as test from "./test.js";
