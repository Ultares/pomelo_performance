import codegen from ".";

var cg = codegen("f", "a")
    ("s", "a");