"use strict";

/**
 * Streaming RPC helpers.
 * @namespace
 */
var rpc = exports;

rpc.Service = require("./rpc/service");
