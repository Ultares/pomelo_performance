export = fetch;

/**
 * Node-style callback as used by {@link util.fetch}.
 * @typedef FetchCallback
 * @type {function}
 * @param {?Error} error Error, if any, otherwise `null`
 * @param {string} [contents] File contents, if there hasn't been an error
 * @returns {undefined}
 */
type FetchCallback = (error: Error, contents?: string) => void;

/**
 * Fetches the contents of a file.
 * @memberof util
 * @param {string} path File path or url
 * @param {FetchCallback} [callback] Callback function
 * @returns {Promise<string>|undefined} A Promise if `callback` has been omitted
 */
declare function fetch(path: string, callback?: FetchCallback): (Promise<string>|undefined);
