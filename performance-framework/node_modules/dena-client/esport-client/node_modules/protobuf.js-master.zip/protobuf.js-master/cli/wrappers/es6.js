import * as $protobuf from "protobufjs";

%OUTPUT%

$protobuf.roots[%ROOT%] = $root;

export { $root as default };
