protobuf.js version: <please fill in>

<please describe the expected and actual behavior>

```js
<please provide a code snippet for reproduction>
```

```
<please paste the stack trace of the error if applicable>
```
