Forked [node-deep-equal](https://github.com/substack/node-deep-equal)@1.0.1 with monkey-patched buffer equality.

License: MIT. Derived largely from node's assert module.
